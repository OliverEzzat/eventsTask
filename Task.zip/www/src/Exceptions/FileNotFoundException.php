<?php

namespace App\Exceptions;

class FileNotFoundException extends \Exception{
     protected $message = 'FILE NOT FOUD';
}