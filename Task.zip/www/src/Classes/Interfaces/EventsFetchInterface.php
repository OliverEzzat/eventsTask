<?php
namespace App\Classes\Interfaces;

interface EventsFetchInterface{

    public function fetch(string $source );
}